# plumes > 2024-10-31 5:30pm
https://universe.roboflow.com/moguscrathiwat/plumes-jznig

Provided by a Roboflow user
License: CC BY 4.0

